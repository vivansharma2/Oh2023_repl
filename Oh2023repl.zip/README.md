# Oh2023_repl
Replication of "DOES IDENTITY AFFECT LABOR SUPPLY?" (Oh, 2023) - Development Economics
